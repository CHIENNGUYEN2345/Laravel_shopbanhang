<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Gửi mail google</title>
</head>
<body>
	<h1>Mail được gửi từ : {{$name}}</h1>
	<h4>Với nội dung : {{$body}}</h4>
</body>
</html>